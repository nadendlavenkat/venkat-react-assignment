import React,{Component} from "react";
class LifeCycle extends Component{
    constructor(props){      
        super(props);
        this.state = {
            count: 0
        };
        console.log("constructor");
    }

    incrementCount = () => {
        console.log("incrementCount");
        this.setState(prevState => ({
            count: prevState.count + 1,
        }));
    }
    decrementCount = () => {
        console.log("decrementCount");
     this.setState(prevState => ({
        count: prevState.count - 1,
     }));

    }

    componentDidMount(){
        console.log("componentDidMount");
    }

    shouldComponentUpdate(nextProps,nextState){
        console.log("shouldComponentUpdate");
        return true;
    }

    componentDidUpdate(){
        console.log("componentDidUpdate");
    }

    componentWillUnmount(){
        console.log("componentWillUnmount");
    }

    render(){
        return (
            <div>
                <h1>count: {this.state.count}</h1>
                <button onClick={this.incrementCount}>incrementCount</button>
                <button onClick={this.decrementCount}>decrementCount</button>
            </div>
        )
    }
}

export default LifeCycle;