import React, { useState } from "react";

function OrderStatus()
{
    // var orderDetail = {
    //     id: 'ORD123',
    //     status: 'Processing',
    //     customer: 'John Doe',
    //     items: 3
    // };
    //const [order, setOrder] = useState(orderDetail);

    const [order, setOrder] = useState({
            id: 'ORD123',
            status: 'Processing',
            customer: 'John Doe',
            items: 3
        });

    function hanldeOrderStatus(event){     
        
        let status = document.getElementById('selectOrderStatus').value;        
      
        let id = order.id;
        let customer = order.customer;
        let items = order.items;
        var orderobj = {
            id: id,
            status: status,
            customer: customer,
            items: items
        };
        setOrder(orderobj); 
    }

    function updateOrderStatus(event){
         
        let status = document.getElementById('selectOrderStatus').value;  
        let id = order.id;
        let customer = order.customer;
        let items = order.items;
        var orderobj = {
            id: id,
            status: status,
            customer: customer,
            items: items
        };
        setOrder(orderobj);       
    }

    return(
        <>
            <h1>React Managing Object State with useState Assignment</h1>
            <select id="selectOrderStatus" value={order.status} onChange={hanldeOrderStatus}>
                <option value="Select">Select</option>
                <option value="Processing">Processing</option>
                <option value="Shipped">Shipped</option>
                <option value="Delivered">Delivered</option>
            </select>
            <button onClick={updateOrderStatus}>Update Status</button>
            <h1>order id: {order.id}</h1>
            <h1>order status:{order.status}</h1>
            <h1>order customer:{order.customer}</h1>
            <h1>order items:{order.items}</h1>
        </>
    );
   
}

export default OrderStatus;