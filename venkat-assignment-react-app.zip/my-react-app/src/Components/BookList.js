import { React, useState } from "react";
const booksArray = [
    {
        id: 1,
        title: "Outliers",
        author: "Malcolm Gladwell",
        price: 400
      },
      {
        id: 2,
        title: "Atomic Habits",
        author: "James Clear",
        price: 471
      },
      {
        id: 3,
        title: "The Power of Now",
        author: "Eckhart Tolle",
        price: 310
      },
      {
        id: 4,
        title: "Man’s Search for Meaning",
        author: "Viktor E. Frankl",
        price: 323
      },
      {
        id: 5,
        title: "Grit",
        author: "Angela Duckworth",
        price: 266
      }
    ];
function BookList(){
    const[books,setbooks] = useState(booksArray);

    const AddBook = (event) =>{
        debugger;
        event.preventDefault();
        const title = event.target.Title.value;
        const author = event.target.Author.value;
        const price = event.target.Price.value;
        var newBook = {
            id:booksArray.length + 1,
            title:title,
            author: author,
            price: price
        };
        setbooks(...books,newBook);
    }
        return (          
            <div>
                
                <form onSubmit={AddBook}>
                        <div>
                            <label htmlFor="Title">Title</label>
                            <input id="Title" name="Title" type="text" placeholder="Title" />
                        </div>
                        <div>
                            <label htmlFor="Author">Author</label>
                            <input id="Author" type="text" name="Author" placeholder="Author" />
                        </div>
                        <div>
                            <label htmlFor="Price">Price</label>
                            <input id="Price" type="text" name="Price" placeholder="Price" />
                        </div>
                        <input type="submit"  />
                    </form>
                            
                <h1>BookList</h1>
                <table>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                             books.map( (book) => (
                                    <tr key={book.id}>
                                        <td>{book.id}</td>
                                        <td>{book.title}</td>
                                        <td>{book.author}</td>
                                        <td>{book.price}</td>
                                    </tr>
                                ))
                            }
                        </tbody>
                </table>
            </div>

        );

}

export default BookList;