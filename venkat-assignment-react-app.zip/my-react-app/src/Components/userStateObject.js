import { useState } from "react";

function User(){
const employee = {
name:"Venkat",
age:26,
salary:35000,
married:true
};

    const[user,setUser] = useState(employee);

    function incrementAge(){
        setUser({...user, age:user.age + 1});
    }

    function incrementSalary(){
        setUser({...user, salary:parseFloat(user.salary) + Math.round(parseFloat((5000/user.salary)*100),2)});
    }
    function addNewProperty(){
        setUser({...user, lastName:"venkat"});
    }
    return (
      <>
        {/* <h1>Counter: {count}</h1>
        <button onClick={incrementCount}>incrementCount</button> */}

        <h1>username:{user.name} and age: {user.age}</h1>
        <h1>userSalary is:{user.salary} and married is {user.married}</h1>
        <h1>lastName is:{user.lastName} </h1>
        <h1><button onClick={incrementAge}>incrementAge</button></h1>
        <h1><button onClick={incrementSalary}>incrementSalary</button></h1>
        <h1><button onClick={addNewProperty}>addNewProperty</button></h1>
      </>   
    )
}

export default User;