import logo from './logo.svg';
import './App.css';

import NumberState from './Components/NumberState';
import NumberStateClass from './Components/NumberStateClass';
import OrderStatus from './Components/OrderStatus';


function App() {

  return (
    <div className="App">
      <OrderStatus />
      <NumberState />
      <NumberStateClass />      
    </div>
  );
}

export default App;
